"${className.toLowerCase()}/:id": "get${className}", 
	"${className.toLowerCase()}s" : "get${className}List"
